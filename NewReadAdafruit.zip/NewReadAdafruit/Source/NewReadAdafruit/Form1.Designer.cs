﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 2018/11/5
 * Time: 10:32
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace NewReadAdafruit
{
	partial class Form1
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
			this.label1 = new System.Windows.Forms.Label();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			this.applyFiltersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.filePathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.label2 = new System.Windows.Forms.Label();
			this.TBElementId = new System.Windows.Forms.TextBox();
			this.TBFileName = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.SelectSensor = new System.Windows.Forms.ComboBox();
			this.ResetFilter = new System.Windows.Forms.Button();
			this.UpdateData = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.DataGridView1 = new System.Windows.Forms.DataGridView();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.NoTempLinePlot = new System.Windows.Forms.Label();
			this.TempLinePlot = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.test = new System.Windows.Forms.TextBox();
			this.tabControl2 = new System.Windows.Forms.TabControl();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.DataGridView2 = new System.Windows.Forms.DataGridView();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.NoHumidLinePlot = new System.Windows.Forms.Label();
			this.HumidLinePlot = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.RoomPhoto = new System.Windows.Forms.PictureBox();
			this.SensorPhoto = new System.Windows.Forms.PictureBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.EnableFaultyOnly = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.SetDate = new System.Windows.Forms.Button();
			this.EnableDateFilter = new System.Windows.Forms.CheckBox();
			this.menuStrip1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
			this.tabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.TempLinePlot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.tabControl2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).BeginInit();
			this.tabPage4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.HumidLinePlot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.RoomPhoto)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SensorPhoto)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(398, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 17);
			this.label1.TabIndex = 3;
			this.label1.Text = "Revit Element ID";
			this.label1.UseCompatibleTextRendering = true;
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			// 
			// openToolStripMenuItem
			// 
			this.openToolStripMenuItem.Name = "openToolStripMenuItem";
			this.openToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			// 
			// exitToolStripMenuItem
			// 
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			this.helpToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.fileToolStripMenuItem1,
									this.toolStripMenuItem2,
									this.helpToolStripMenuItem1});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(875, 24);
			this.menuStrip1.TabIndex = 10;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem1
			// 
			this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.toolStripMenuItem3,
									this.toolStripMenuItem1,
									this.toolStripSeparator1,
									this.exitToolStripMenuItem1});
			this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
			this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
			this.fileToolStripMenuItem1.Text = "File";
			// 
			// toolStripMenuItem3
			// 
			this.toolStripMenuItem3.Name = "toolStripMenuItem3";
			this.toolStripMenuItem3.Size = new System.Drawing.Size(145, 22);
			this.toolStripMenuItem3.Text = "Sync All Data";
			this.toolStripMenuItem3.Click += new System.EventHandler(this.ToolStripMenuItem3Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
			this.toolStripMenuItem1.Text = "Clear All Data";
			this.toolStripMenuItem1.Click += new System.EventHandler(this.ToolStripMenuItem1Click);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(142, 6);
			// 
			// exitToolStripMenuItem1
			// 
			this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
			this.exitToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
			this.exitToolStripMenuItem1.Text = "Exit";
			this.exitToolStripMenuItem1.Click += new System.EventHandler(this.ExitToolStripMenuItem1Click);
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.applyFiltersToolStripMenuItem,
									this.filePathToolStripMenuItem});
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			this.toolStripMenuItem2.Size = new System.Drawing.Size(39, 20);
			this.toolStripMenuItem2.Text = "Edit";
			// 
			// applyFiltersToolStripMenuItem
			// 
			this.applyFiltersToolStripMenuItem.Name = "applyFiltersToolStripMenuItem";
			this.applyFiltersToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
			this.applyFiltersToolStripMenuItem.Text = "Comfort Zone...";
			this.applyFiltersToolStripMenuItem.Click += new System.EventHandler(this.ApplyFiltersToolStripMenuItemClick);
			// 
			// filePathToolStripMenuItem
			// 
			this.filePathToolStripMenuItem.Name = "filePathToolStripMenuItem";
			this.filePathToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
			this.filePathToolStripMenuItem.Text = "File Path...";
			// 
			// helpToolStripMenuItem1
			// 
			this.helpToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.helpToolStripMenuItem2,
									this.aboutToolStripMenuItem});
			this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
			this.helpToolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
			this.helpToolStripMenuItem1.Text = "Help";
			// 
			// helpToolStripMenuItem2
			// 
			this.helpToolStripMenuItem2.Name = "helpToolStripMenuItem2";
			this.helpToolStripMenuItem2.Size = new System.Drawing.Size(116, 22);
			this.helpToolStripMenuItem2.Text = "Help";
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
			this.aboutToolStripMenuItem.Text = "About...";
			this.aboutToolStripMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItemClick);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(23, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(60, 17);
			this.label2.TabIndex = 12;
			this.label2.Text = "Sensor";
			this.label2.UseCompatibleTextRendering = true;
			// 
			// TBElementId
			// 
			this.TBElementId.Location = new System.Drawing.Point(502, 45);
			this.TBElementId.Name = "TBElementId";
			this.TBElementId.ReadOnly = true;
			this.TBElementId.Size = new System.Drawing.Size(119, 20);
			this.TBElementId.TabIndex = 13;
			// 
			// TBFileName
			// 
			this.TBFileName.Location = new System.Drawing.Point(97, 600);
			this.TBFileName.Name = "TBFileName";
			this.TBFileName.ReadOnly = true;
			this.TBFileName.Size = new System.Drawing.Size(325, 20);
			this.TBFileName.TabIndex = 19;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(23, 603);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(60, 17);
			this.label5.TabIndex = 20;
			this.label5.Text = "File Path";
			this.label5.UseCompatibleTextRendering = true;
			// 
			// SelectSensor
			// 
			this.SelectSensor.FormattingEnabled = true;
			this.SelectSensor.Items.AddRange(new object[] {
									"Watt Hall Building Science Corner",
									"Watt Hall Upper Rosendin",
									"Watt Hall Lower Rosendin",
									"Watt Hall 212",
									"Watt Hall B1"});
			this.SelectSensor.Location = new System.Drawing.Point(77, 44);
			this.SelectSensor.Name = "SelectSensor";
			this.SelectSensor.Size = new System.Drawing.Size(272, 21);
			this.SelectSensor.TabIndex = 21;
			this.SelectSensor.SelectedIndexChanged += new System.EventHandler(this.SelectSensorSelectedIndexChanged);
			// 
			// ResetFilter
			// 
			this.ResetFilter.Enabled = false;
			this.ResetFilter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.ResetFilter.Location = new System.Drawing.Point(527, 82);
			this.ResetFilter.Name = "ResetFilter";
			this.ResetFilter.Size = new System.Drawing.Size(94, 20);
			this.ResetFilter.TabIndex = 24;
			this.ResetFilter.Text = "Reset Filter";
			this.ResetFilter.UseCompatibleTextRendering = true;
			this.ResetFilter.UseVisualStyleBackColor = true;
			this.ResetFilter.Click += new System.EventHandler(this.ResetFilterClick);
			// 
			// UpdateData
			// 
			this.UpdateData.Enabled = false;
			this.UpdateData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.UpdateData.Location = new System.Drawing.Point(427, 82);
			this.UpdateData.Name = "UpdateData";
			this.UpdateData.Size = new System.Drawing.Size(94, 20);
			this.UpdateData.TabIndex = 25;
			this.UpdateData.Text = "Update Data";
			this.UpdateData.UseCompatibleTextRendering = true;
			this.UpdateData.UseVisualStyleBackColor = true;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(23, 97);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(598, 232);
			this.tabControl1.TabIndex = 26;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.DataGridView1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(590, 206);
			this.tabPage1.TabIndex = 1;
			this.tabPage1.Text = "Temp Data Table";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// DataGridView1
			// 
			this.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DataGridView1.GridColor = System.Drawing.SystemColors.AppWorkspace;
			this.DataGridView1.Location = new System.Drawing.Point(0, 0);
			this.DataGridView1.Name = "DataGridView1";
			this.DataGridView1.Size = new System.Drawing.Size(590, 206);
			this.DataGridView1.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.NoTempLinePlot);
			this.tabPage2.Controls.Add(this.TempLinePlot);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(590, 206);
			this.tabPage2.TabIndex = 0;
			this.tabPage2.Text = "Temp Data Line Plot";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// NoTempLinePlot
			// 
			this.NoTempLinePlot.Location = new System.Drawing.Point(0, 0);
			this.NoTempLinePlot.Name = "NoTempLinePlot";
			this.NoTempLinePlot.Size = new System.Drawing.Size(594, 206);
			this.NoTempLinePlot.TabIndex = 1;
			this.NoTempLinePlot.Text = "Data line plot is temporarily not available.";
			this.NoTempLinePlot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.NoTempLinePlot.UseCompatibleTextRendering = true;
			// 
			// TempLinePlot
			// 
			chartArea1.Name = "ChartArea1";
			this.TempLinePlot.ChartAreas.Add(chartArea1);
			legend1.Name = "Legend1";
			this.TempLinePlot.Legends.Add(legend1);
			this.TempLinePlot.Location = new System.Drawing.Point(0, 0);
			this.TempLinePlot.Name = "TempLinePlot";
			this.TempLinePlot.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
			series1.ChartArea = "ChartArea1";
			series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
			series1.Legend = "Legend1";
			series1.Name = "Temperature (℉)";
			this.TempLinePlot.Series.Add(series1);
			this.TempLinePlot.Size = new System.Drawing.Size(590, 206);
			this.TempLinePlot.TabIndex = 0;
			this.TempLinePlot.Text = "Temp Data Line Plot";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(730, 579);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(116, 76);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 27;
			this.pictureBox1.TabStop = false;
			// 
			// test
			// 
			this.test.Location = new System.Drawing.Point(429, 600);
			this.test.Name = "test";
			this.test.Size = new System.Drawing.Size(43, 20);
			this.test.TabIndex = 28;
			// 
			// tabControl2
			// 
			this.tabControl2.Controls.Add(this.tabPage3);
			this.tabControl2.Controls.Add(this.tabPage4);
			this.tabControl2.Location = new System.Drawing.Point(23, 344);
			this.tabControl2.Name = "tabControl2";
			this.tabControl2.SelectedIndex = 0;
			this.tabControl2.Size = new System.Drawing.Size(598, 232);
			this.tabControl2.TabIndex = 29;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.DataGridView2);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(590, 206);
			this.tabPage3.TabIndex = 0;
			this.tabPage3.Text = "RH Data Table";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// DataGridView2
			// 
			this.DataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.DataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DataGridView2.GridColor = System.Drawing.SystemColors.AppWorkspace;
			this.DataGridView2.Location = new System.Drawing.Point(0, 0);
			this.DataGridView2.Name = "DataGridView2";
			this.DataGridView2.Size = new System.Drawing.Size(590, 206);
			this.DataGridView2.TabIndex = 0;
			// 
			// tabPage4
			// 
			this.tabPage4.Controls.Add(this.NoHumidLinePlot);
			this.tabPage4.Controls.Add(this.HumidLinePlot);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage4.Size = new System.Drawing.Size(590, 206);
			this.tabPage4.TabIndex = 1;
			this.tabPage4.Text = "RH Data Line Plot";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// NoHumidLinePlot
			// 
			this.NoHumidLinePlot.Location = new System.Drawing.Point(0, 0);
			this.NoHumidLinePlot.Name = "NoHumidLinePlot";
			this.NoHumidLinePlot.Size = new System.Drawing.Size(590, 206);
			this.NoHumidLinePlot.TabIndex = 0;
			this.NoHumidLinePlot.Text = "Data line plot is temporarily not available.";
			this.NoHumidLinePlot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.NoHumidLinePlot.UseCompatibleTextRendering = true;
			// 
			// HumidLinePlot
			// 
			chartArea2.Name = "ChartArea1";
			this.HumidLinePlot.ChartAreas.Add(chartArea2);
			legend2.Name = "Legend1";
			this.HumidLinePlot.Legends.Add(legend2);
			this.HumidLinePlot.Location = new System.Drawing.Point(0, 0);
			this.HumidLinePlot.Name = "HumidLinePlot";
			this.HumidLinePlot.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
			series2.ChartArea = "ChartArea1";
			series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
			series2.Legend = "Legend1";
			series2.Name = "Relative Humidity (%)";
			this.HumidLinePlot.Series.Add(series2);
			this.HumidLinePlot.Size = new System.Drawing.Size(590, 206);
			this.HumidLinePlot.TabIndex = 1;
			this.HumidLinePlot.Text = "RH Data Line Plot";
			// 
			// RoomPhoto
			// 
			this.RoomPhoto.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.RoomPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.RoomPhoto.Location = new System.Drawing.Point(646, 119);
			this.RoomPhoto.Name = "RoomPhoto";
			this.RoomPhoto.Size = new System.Drawing.Size(200, 150);
			this.RoomPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.RoomPhoto.TabIndex = 31;
			this.RoomPhoto.TabStop = false;
			// 
			// SensorPhoto
			// 
			this.SensorPhoto.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.SensorPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.SensorPhoto.Location = new System.Drawing.Point(646, 304);
			this.SensorPhoto.Name = "SensorPhoto";
			this.SensorPhoto.Size = new System.Drawing.Size(200, 150);
			this.SensorPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.SensorPhoto.TabIndex = 32;
			this.SensorPhoto.TabStop = false;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(646, 276);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 33;
			this.label3.Text = "Room Photo";
			this.label3.UseCompatibleTextRendering = true;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(646, 461);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 23);
			this.label4.TabIndex = 34;
			this.label4.Text = "Sensor Photo";
			this.label4.UseCompatibleTextRendering = true;
			// 
			// EnableFaultyOnly
			// 
			this.EnableFaultyOnly.Enabled = false;
			this.EnableFaultyOnly.Location = new System.Drawing.Point(11, 23);
			this.EnableFaultyOnly.Name = "EnableFaultyOnly";
			this.EnableFaultyOnly.Size = new System.Drawing.Size(124, 24);
			this.EnableFaultyOnly.TabIndex = 35;
			this.EnableFaultyOnly.Text = "Faulty Value Only";
			this.EnableFaultyOnly.UseCompatibleTextRendering = true;
			this.EnableFaultyOnly.UseVisualStyleBackColor = true;
			this.EnableFaultyOnly.CheckedChanged += new System.EventHandler(this.FaultyOnlyCheckedChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.SetDate);
			this.groupBox1.Controls.Add(this.EnableDateFilter);
			this.groupBox1.Controls.Add(this.EnableFaultyOnly);
			this.groupBox1.Location = new System.Drawing.Point(648, 485);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(198, 90);
			this.groupBox1.TabIndex = 36;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Display Settings";
			this.groupBox1.UseCompatibleTextRendering = true;
			// 
			// SetDate
			// 
			this.SetDate.Enabled = false;
			this.SetDate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.SetDate.Location = new System.Drawing.Point(107, 51);
			this.SetDate.Name = "SetDate";
			this.SetDate.Size = new System.Drawing.Size(75, 20);
			this.SetDate.TabIndex = 37;
			this.SetDate.Text = "Setup...";
			this.SetDate.UseCompatibleTextRendering = true;
			this.SetDate.UseVisualStyleBackColor = true;
			this.SetDate.Click += new System.EventHandler(this.SetDateClick);
			// 
			// EnableDateFilter
			// 
			this.EnableDateFilter.Enabled = false;
			this.EnableDateFilter.Location = new System.Drawing.Point(11, 50);
			this.EnableDateFilter.Name = "EnableDateFilter";
			this.EnableDateFilter.Size = new System.Drawing.Size(87, 24);
			this.EnableDateFilter.TabIndex = 36;
			this.EnableDateFilter.Text = "Date Filter";
			this.EnableDateFilter.UseCompatibleTextRendering = true;
			this.EnableDateFilter.UseVisualStyleBackColor = true;
			this.EnableDateFilter.CheckedChanged += new System.EventHandler(this.EnableDateFilterCheckedChanged);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(875, 649);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.SensorPhoto);
			this.Controls.Add(this.RoomPhoto);
			this.Controls.Add(this.tabControl2);
			this.Controls.Add(this.test);
			this.Controls.Add(this.ResetFilter);
			this.Controls.Add(this.UpdateData);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.SelectSensor);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.TBFileName);
			this.Controls.Add(this.TBElementId);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.menuStrip1);
			this.Controls.Add(this.pictureBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "Adafruit IO Reader - Ver. 0.5";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
			this.tabPage2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.TempLinePlot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.tabControl2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).EndInit();
			this.tabPage4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.HumidLinePlot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.RoomPhoto)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SensorPhoto)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
        public System.Windows.Forms.CheckBox EnableDateFilter;
        public System.Windows.Forms.Button SetDate;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.CheckBox EnableFaultyOnly;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.PictureBox SensorPhoto;
        public System.Windows.Forms.PictureBox RoomPhoto;
        public System.Windows.Forms.DataVisualization.Charting.Chart HumidLinePlot;
        public System.Windows.Forms.DataGridView DataGridView2;
        public System.Windows.Forms.Label NoHumidLinePlot;
        public System.Windows.Forms.TabPage tabPage4;
        public System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.TabControl tabControl2;
        public System.Windows.Forms.TextBox test;
        public System.Windows.Forms.ToolStripMenuItem filePathToolStripMenuItem;
        public System.Windows.Forms.Label NoTempLinePlot;
        public System.Windows.Forms.DataVisualization.Charting.Chart TempLinePlot;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.DataGridView DataGridView1;
        public System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.TabControl tabControl1;
        public System.Windows.Forms.Button UpdateData;
        public System.Windows.Forms.ToolStripMenuItem applyFiltersToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        public System.Windows.Forms.Button ResetFilter;
        public System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem2;
        public System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox TBFileName;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.ComboBox SelectSensor;
        public System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        public System.Windows.Forms.Label label1;
		public System.Windows.Forms.TextBox TBElementId;
	}
}
