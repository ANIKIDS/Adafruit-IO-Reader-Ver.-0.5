﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 12/3/2018
 * Time: 15:02
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace NewReadAdafruit
{
	partial class Form3
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.LowTemp = new System.Windows.Forms.TextBox();
			this.HighTemp = new System.Windows.Forms.TextBox();
			this.LowHumid = new System.Windows.Forms.TextBox();
			this.HighHumid = new System.Windows.Forms.TextBox();
			this.preset = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lowTemp
			// 
			this.LowTemp.Enabled = false;
			this.LowTemp.Location = new System.Drawing.Point(179, 62);
			this.LowTemp.Name = "lowTemp";
			this.LowTemp.Size = new System.Drawing.Size(53, 20);
			this.LowTemp.TabIndex = 0;
			// 
			// highTemp
			// 
			this.HighTemp.Enabled = false;
			this.HighTemp.Location = new System.Drawing.Point(292, 62);
			this.HighTemp.Name = "highTemp";
			this.HighTemp.Size = new System.Drawing.Size(53, 20);
			this.HighTemp.TabIndex = 1;
			// 
			// lowHumid
			// 
			this.LowHumid.Enabled = false;
			this.LowHumid.Location = new System.Drawing.Point(179, 88);
			this.LowHumid.Name = "lowHumid";
			this.LowHumid.Size = new System.Drawing.Size(53, 20);
			this.LowHumid.TabIndex = 2;
			// 
			// highHumid
			// 
			this.HighHumid.Enabled = false;
			this.HighHumid.Location = new System.Drawing.Point(292, 88);
			this.HighHumid.Name = "highHumid";
			this.HighHumid.Size = new System.Drawing.Size(53, 20);
			this.HighHumid.TabIndex = 3;
			// 
			// preset
			// 
			this.preset.FormattingEnabled = true;
			this.preset.Items.AddRange(new object[] {
									"ASHRAE 55-2017",
									"ISO 7730 - Summer",
									"ISO 7730 - Winter",
									"----------------------",
									"Test Option 1",
									"Test Option 2",
									"Customize..."});
			this.preset.Location = new System.Drawing.Point(143, 21);
			this.preset.Name = "preset";
			this.preset.Size = new System.Drawing.Size(202, 21);
			this.preset.TabIndex = 4;
			this.preset.SelectedIndexChanged += new System.EventHandler(this.PresetSelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(21, 24);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 18);
			this.label2.TabIndex = 5;
			this.label2.Text = "Preset";
			this.label2.UseCompatibleTextRendering = true;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(143, 65);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(28, 17);
			this.label3.TabIndex = 6;
			this.label3.Text = "Low";
			this.label3.UseCompatibleTextRendering = true;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(143, 91);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(28, 17);
			this.label4.TabIndex = 7;
			this.label4.Text = "Low";
			this.label4.UseCompatibleTextRendering = true;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(254, 65);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(35, 17);
			this.label5.TabIndex = 8;
			this.label5.Text = "High";
			this.label5.UseCompatibleTextRendering = true;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(254, 91);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(35, 17);
			this.label6.TabIndex = 9;
			this.label6.Text = "High";
			this.label6.UseCompatibleTextRendering = true;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(21, 65);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 19);
			this.label7.TabIndex = 10;
			this.label7.Text = "Temperature (℉)";
			this.label7.UseCompatibleTextRendering = true;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(21, 91);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(122, 17);
			this.label8.TabIndex = 11;
			this.label8.Text = "Relative Humidity (%)";
			this.label8.UseCompatibleTextRendering = true;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(179, 130);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 12;
			this.button1.Text = "OK";
			this.button1.UseCompatibleTextRendering = true;
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(270, 130);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 13;
			this.button2.Text = "Cancel";
			this.button2.UseCompatibleTextRendering = true;
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// Form3
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(372, 168);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.preset);
			this.Controls.Add(this.HighHumid);
			this.Controls.Add(this.LowHumid);
			this.Controls.Add(this.HighTemp);
			this.Controls.Add(this.LowTemp);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form3";
			this.Text = "Comfort Zone";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox preset;
		public System.Windows.Forms.TextBox HighHumid;
		public System.Windows.Forms.TextBox LowHumid;
		public System.Windows.Forms.TextBox HighTemp;
		public System.Windows.Forms.TextBox LowTemp;
	}
}
