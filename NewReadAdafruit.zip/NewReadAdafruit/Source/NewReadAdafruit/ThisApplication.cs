﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 11/8/2018
 * Time: 9:06 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using System.IO;
using System.Collections.Generic;
using System.Linq;

// File Path: C:\ProgramData\Autodesk\Revit\Macros\2018\Revit\AppHookup

namespace NewReadAdafruit
{
	[Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
	[Autodesk.Revit.DB.Macros.AddInId("4E5A91BC-719B-4083-93D3-BF1801EAD552")]
	public partial class ThisApplication
	{
		private void Module_Startup(object sender, EventArgs e)
		{

		}

		private void Module_Shutdown(object sender, EventArgs e)
		{

		}

		#region Revit Macros generated code
		private void InternalStartup()
		{
			this.Startup += new System.EventHandler(Module_Startup);
			this.Shutdown += new System.EventHandler(Module_Shutdown);
		}
		#endregion

		#region Main Program
		
		public void F_Main_Program()
		{
			
			using(var form = new Form1())
			{
				// Set comfort zone to ASHRAE 55-2017
				Form3.LT = "68";
				Form3.HT = "78";
				Form3.LH = "20";
				Form3.HH = "80";
				
				// Show Form1 from Revit Macro
				form.ShowDialog();
			}
		}
		
		#endregion

		#region Reset color schemes
		
		public void G_Reset()
		{
			Document doc = this.ActiveUIDocument.Document;
			UIDocument uidoc = this.ActiveUIDocument;
			
			// Highlight the sensor by element ID or by picking from the 3D view.
			
			ElementId ResetId = new ElementId(1304799);
			
			for (int ColorReset = 0; ColorReset <= 4; ColorReset++)
			{
				if (ColorReset == 0) {ResetId = new ElementId(1304799);}
				if (ColorReset == 1) {ResetId = new ElementId(1304568);}
				if (ColorReset == 2) {ResetId = new ElementId(1305148);}
				if (ColorReset == 3) {ResetId = new ElementId(1304930);}
				if (ColorReset == 4) {ResetId = new ElementId(1305363);}
				
				OverrideGraphicSettings ResetOgs = new OverrideGraphicSettings();
				ResetOgs.SetProjectionLineColor(new Autodesk.Revit.DB.Color(0,0,0));
				using (Transaction t = new Transaction(doc,"Set Element Override"))
				{
					t.Start();
					// Apply color scheme to the selected element.
					doc.ActiveView.SetElementOverrides(ResetId, ResetOgs);
					
					// Zoom to fit.
					//uidoc.ShowElements(id);
					t.Commit();
				}
			}
		}
		
		#endregion
				
		#region Sensor 1: Watt Hall Building Science Corner
		
		public void A_Watt_Hall_Building_Science_Corner()
		{
			#region Declare variables
			
			Form1 Mainform = new Form1();
			Form1.RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
			Form1.PicRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Pictures\";
			Mainform.SelectSensor.Text = "Watt Hall Building Science Corner";
			
			Document doc = this.ActiveUIDocument.Document;
			UIDocument uidoc = this.ActiveUIDocument;
			View view = doc.ActiveView;
			UIView uiview = null;
			IList<UIView> uiviews = uidoc.GetOpenUIViews();
			
			#endregion
			
			#region Reset color schemes and set new ones
			
			G_Reset();
			
			ElementId ColorSchemeId = new ElementId(1304799);
			OverrideGraphicSettings NewOgs = new OverrideGraphicSettings();
			NewOgs.SetProjectionLineColor(new Autodesk.Revit.DB.Color(255,0,0));
			
			using (Transaction t = new Transaction(doc,"Set Element Override"))
			{
				t.Start();
				doc.ActiveView.SetElementOverrides(ColorSchemeId, NewOgs);
				uidoc.ShowElements(ColorSchemeId);
				t.Commit();
			}
			
			#endregion
			
			#region Zoom out
			
			foreach(UIView uv in uiviews)
			{
				if(uv.ViewId.Equals(view.Id))
				{
					uiview = uv;
					break;
				}
			}
			
			Rectangle rect = uiview.GetWindowRectangle();
			IList<XYZ> corners = uiview.GetZoomCorners();
			XYZ p = corners[0];
			XYZ q = corners[1];
			XYZ v = q - p;
			XYZ center = p + 0.5 * v;
			v *= 10; // Zoom out if bigger than 1; Zoom in if smaller than 1
			p = center - v;
			q = center + v;
			
			uiview.ZoomAndCenterRectangle(p,q);
			
			#endregion
			
			#region Initialize main program
			
			// Set comfort zone to ASHRAE 55-2017
			Form3.LT = "68";
			Form3.HT = "78";
			Form3.LH = "20";
			Form3.HH = "80";

			Mainform.ShowDialog();
			Mainform.LoadDgv();
			
			#endregion
		}
		
		#endregion
		
		#region Sensor 2: Watt Hall Upper Rosendin
		
		public void B_Watt_Hall_Upper_Rosendin()
		{
			#region Declare variables
			
			Form1 Mainform = new Form1();
			Form1.RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
			Form1.PicRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Pictures\";
			Mainform.SelectSensor.Text = "Watt Hall Upper Rosendin";
			
			Document doc = this.ActiveUIDocument.Document;
			UIDocument uidoc = this.ActiveUIDocument;
			View view = doc.ActiveView;
			UIView uiview = null;
			IList<UIView> uiviews = uidoc.GetOpenUIViews();
			
			#endregion
			
			#region Reset color schemes and set new ones
			
			G_Reset();
			
			ElementId ColorSchemeId = new ElementId(1304568);
			OverrideGraphicSettings NewOgs = new OverrideGraphicSettings();
			NewOgs.SetProjectionLineColor(new Autodesk.Revit.DB.Color(255,0,0));
			
			using (Transaction t = new Transaction(doc,"Set Element Override"))
			{
				t.Start();
				doc.ActiveView.SetElementOverrides(ColorSchemeId, NewOgs);
				uidoc.ShowElements(ColorSchemeId);
				t.Commit();
			}
			
			#endregion
			
			#region Zoom out
			
			foreach(UIView uv in uiviews)
			{
				if(uv.ViewId.Equals(view.Id))
				{
					uiview = uv;
					break;
				}
			}
			
			Rectangle rect = uiview.GetWindowRectangle();
			IList<XYZ> corners = uiview.GetZoomCorners();
			XYZ p = corners[0];
			XYZ q = corners[1];
			XYZ v = q - p;
			XYZ center = p + 0.5 * v;
			v *= 13; // Zoom out if bigger than 1; Zoom in if smaller than 1
			p = center - v;
			q = center + v;
			
			uiview.ZoomAndCenterRectangle(p,q);
			
			#endregion
			
			#region Initialize main program
			
			// Set comfort zone to ASHRAE 55-2017
			Form3.LT = "68";
			Form3.HT = "78";
			Form3.LH = "20";
			Form3.HH = "80";

			Mainform.ShowDialog();
			Mainform.LoadDgv();
			
			#endregion
		}
		
		#endregion
		
		#region Sensor 3: Watt Hall Lower Rosendin
		
		public void C_Watt_Hall_Lower_Rosendin()
		{
			#region Declare variables
			
			Form1 Mainform = new Form1();
			Form1.RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
			Form1.PicRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Pictures\";
			Mainform.SelectSensor.Text = "Watt Hall Lower Rosendin";
			
			Document doc = this.ActiveUIDocument.Document;
			UIDocument uidoc = this.ActiveUIDocument;
			View view = doc.ActiveView;
			UIView uiview = null;
			IList<UIView> uiviews = uidoc.GetOpenUIViews();
			
			#endregion
			
			#region Reset color schemes and set new ones
			
			G_Reset();
			
			ElementId ColorSchemeId = new ElementId(1305148);
			OverrideGraphicSettings NewOgs = new OverrideGraphicSettings();
			NewOgs.SetProjectionLineColor(new Autodesk.Revit.DB.Color(255,0,0));
			
			using (Transaction t = new Transaction(doc,"Set Element Override"))
			{
				t.Start();
				doc.ActiveView.SetElementOverrides(ColorSchemeId, NewOgs);
				uidoc.ShowElements(ColorSchemeId);
				t.Commit();
			}
			
			#endregion
			
			#region Zoom out
			
			foreach(UIView uv in uiviews)
			{
				if(uv.ViewId.Equals(view.Id))
				{
					uiview = uv;
					break;
				}
			}
			
			Rectangle rect = uiview.GetWindowRectangle();
			IList<XYZ> corners = uiview.GetZoomCorners();
			XYZ p = corners[0];
			XYZ q = corners[1];
			XYZ v = q - p;
			XYZ center = p + 0.5 * v;
			v *= 5; // Zoom out if bigger than 1; Zoom in if smaller than 1
			p = center - v;
			q = center + v;
			
			uiview.ZoomAndCenterRectangle(p,q);
			
			#endregion
			
			#region Initialize main program
			
			// Set comfort zone to ASHRAE 55-2017
			Form3.LT = "68";
			Form3.HT = "78";
			Form3.LH = "20";
			Form3.HH = "80";

			Mainform.ShowDialog();
			Mainform.LoadDgv();
			
			#endregion
		}
		
		#endregion
		
		#region Sensor 4: Watt Hall 212
		
		public void D_Watt_Hall_212()
		{
			#region Declare variables
			
			Form1 Mainform = new Form1();
			Form1.RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
			Form1.PicRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Pictures\";
			Mainform.SelectSensor.Text = "Watt Hall 212";
			
			Document doc = this.ActiveUIDocument.Document;
			UIDocument uidoc = this.ActiveUIDocument;
			View view = doc.ActiveView;
			UIView uiview = null;
			IList<UIView> uiviews = uidoc.GetOpenUIViews();
			
			#endregion
			
			#region Reset color schemes and set new ones
			
			G_Reset();
			
			ElementId ColorSchemeId = new ElementId(1304930);
			OverrideGraphicSettings NewOgs = new OverrideGraphicSettings();
			NewOgs.SetProjectionLineColor(new Autodesk.Revit.DB.Color(255,0,0));
			
			using (Transaction t = new Transaction(doc,"Set Element Override"))
			{
				t.Start();
				doc.ActiveView.SetElementOverrides(ColorSchemeId, NewOgs);
				uidoc.ShowElements(ColorSchemeId);
				t.Commit();
			}
			
			#endregion
			
			#region Zoom out
			
			foreach(UIView uv in uiviews)
			{
				if(uv.ViewId.Equals(view.Id))
				{
					uiview = uv;
					break;
				}
			}
			
			Rectangle rect = uiview.GetWindowRectangle();
			IList<XYZ> corners = uiview.GetZoomCorners();
			XYZ p = corners[0];
			XYZ q = corners[1];
			XYZ v = q - p;
			XYZ center = p + 0.5 * v;
			v *= 15; // Zoom out if bigger than 1; Zoom in if smaller than 1
			p = center - v;
			q = center + v;
			
			uiview.ZoomAndCenterRectangle(p,q);
			
			#endregion
			
			#region Initialize main program
			
			// Set comfort zone to ASHRAE 55-2017
			Form3.LT = "68";
			Form3.HT = "78";
			Form3.LH = "20";
			Form3.HH = "80";

			Mainform.ShowDialog();
			Mainform.LoadDgv();
			
			#endregion
		}
		
		#endregion
		
		#region Sensor 5: Watt Hall B1
		
		public void E_Watt_Hall_B1()
		{
			#region Declare variables
			
			Form1 Mainform = new Form1();
			Form1.RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
			Form1.PicRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Pictures\";
			Mainform.SelectSensor.Text = "Watt Hall B1";
			
			Document doc = this.ActiveUIDocument.Document;
			UIDocument uidoc = this.ActiveUIDocument;
			View view = doc.ActiveView;
			UIView uiview = null;
			IList<UIView> uiviews = uidoc.GetOpenUIViews();
			
			#endregion
			
			#region Reset color schemes and set new ones
			
			G_Reset();
			
			ElementId ColorSchemeId = new ElementId(1305363);
			OverrideGraphicSettings NewOgs = new OverrideGraphicSettings();
			NewOgs.SetProjectionLineColor(new Autodesk.Revit.DB.Color(255,0,0));
			
			using (Transaction t = new Transaction(doc,"Set Element Override"))
			{
				t.Start();
				doc.ActiveView.SetElementOverrides(ColorSchemeId, NewOgs);
				uidoc.ShowElements(ColorSchemeId);
				t.Commit();
			}
			
			#endregion
			
			#region Zoom out
			
			foreach(UIView uv in uiviews)
			{
				if(uv.ViewId.Equals(view.Id))
				{
					uiview = uv;
					break;
				}
			}
			
			Rectangle rect = uiview.GetWindowRectangle();
			IList<XYZ> corners = uiview.GetZoomCorners();
			XYZ p = corners[0];
			XYZ q = corners[1];
			XYZ v = q - p;
			XYZ center = p + 0.5 * v;
			v *= 20; // Zoom out if bigger than 1; Zoom in if smaller than 1
			p = center - v;
			q = center + v;
			
			uiview.ZoomAndCenterRectangle(p,q);
			
			#endregion
			
			#region Initialize main program
			
			// Set comfort zone to ASHRAE 55-2017
			Form3.LT = "68";
			Form3.HT = "78";
			Form3.LH = "20";
			Form3.HH = "80";

			Mainform.ShowDialog();
			Mainform.LoadDgv();
			
			#endregion
		}
		
		#endregion
	}
}
