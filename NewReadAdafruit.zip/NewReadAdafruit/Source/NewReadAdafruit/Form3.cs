﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 12/3/2018
 * Time: 15:02
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace NewReadAdafruit
{
	/// <summary>
	/// Description of Form3.
	/// </summary>
	public partial class Form3 : Form
	{
		// Declaration of the main form.
		Form1 MainForm;
		
		//=============================Strings======================================//
		
		public static string LT;
		public static string HT;
		public static string LH;
		public static string HH;
		
		string ComfortRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\";
		
		//=============================Form3 Initialization=========================//
		
		public Form3(Form1 MainForm)
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			this.MainForm = MainForm;
			
			// Set default value
			preset.Text = "ASHRAE 55-2017";
			LowTemp.Text = "68";
			HighTemp.Text = "78";
			LowHumid.Text = "20";
			HighHumid.Text = "80";
			

			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		public void DisableBoxes()
		{
			LowTemp.Enabled = false;
			HighTemp.Enabled = false;
			LowHumid.Enabled = false;
			HighHumid.Enabled = false;
		}
		
		void PresetSelectedIndexChanged(object sender, EventArgs e)
		{
			if(preset.Text == "ASHRAE 55-2017")
			{
				DisableBoxes();
				LowTemp.Text = "66";
				HighTemp.Text = "84";
				LowHumid.Text = "20";
				HighHumid.Text = "80";
			}
			
			if(preset.Text == "ISO 7730 - Winter")
			{
				DisableBoxes();
				LowTemp.Text = "68";
				HighTemp.Text = "75.2";
				LowHumid.Text = "30";
				HighHumid.Text = "70";
			}
			
			if(preset.Text == "ISO 7730 - Summer")
			{
				DisableBoxes();
				LowTemp.Text = "73.4";
				HighTemp.Text = "78.8";
				LowHumid.Text = "30";
				HighHumid.Text = "70";
			}
			
			if(preset.Text == "Test Option 1")
			{
				DisableBoxes();
				LowTemp.Text = "68";
				HighTemp.Text = "72";
				LowHumid.Text = "20";
				HighHumid.Text = "80";
			}
			
			if(preset.Text == "Test Option 2")
			{
				DisableBoxes();
				LowTemp.Text = "72";
				HighTemp.Text = "78";
				LowHumid.Text = "20";
				HighHumid.Text = "80";
			}
			
			if(preset.Text == "Customize...")
			{
				LowTemp.Enabled = true;
				HighTemp.Enabled = true;
				LowHumid.Enabled = true;
				HighHumid.Enabled = true;
				
				// Values need to be read from the file			
				LowTemp.Text = File.ReadLines(ComfortRepository + "Customized Comfort Zone.txt").Skip(0).Take(1).First();
				HighTemp.Text = File.ReadLines(ComfortRepository + "Customized Comfort Zone.txt").Skip(1).Take(1).First();
				LowHumid.Text = File.ReadLines(ComfortRepository + "Customized Comfort Zone.txt").Skip(2).Take(1).First();
				HighHumid.Text = File.ReadLines(ComfortRepository + "Customized Comfort Zone.txt").Skip(3).Take(1).First();
			}
		}
		
		// Button -- OK
		void Button1Click(object sender, EventArgs e)
		{
			// Data validation
			int InvalidTemp = string.Compare(LowTemp.Text, HighTemp.Text);
			if (InvalidTemp == 1)
			{
				MessageBox.Show("The low value cannot be higher than the high value.","Invalid Temperature Range",
				                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
				LowTemp.Focus();
				return;
			}
			
			int InvalidHumid = string.Compare(LowHumid.Text, HighHumid.Text);
			if (InvalidHumid == 1)
			{
				MessageBox.Show("The low value cannot be higher than the high value.","Invalid Relative Humidity Range",
				                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
				LowHumid.Focus();
				return;
			}
			
			if (string.IsNullOrWhiteSpace(LowTemp.Text) || string.IsNullOrWhiteSpace(HighTemp.Text) ||
			    string.IsNullOrWhiteSpace(LowHumid.Text) || string.IsNullOrWhiteSpace(HighHumid.Text))
			{
				MessageBox.Show("Please enter valid values.","Data is missing",
				                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
				return;
			}
			
			LT = LowTemp.Text;
			HT = HighTemp.Text;
			LH = LowHumid.Text;
			HH = HighHumid.Text;
			
			// Use presets
			if (preset.Text != "Customize...")
			{
				// Just refresh data grid views.
				MainForm.LoadDgv();
				// MainForm.ToRevit();
				Close();
			}
			
			// Use customized comfort zone
			else
			{
				// Write comfort zone to a file

				string[] lines = {LT, HT, LH, HH};
				System.IO.File.WriteAllLines(ComfortRepository + "Customized Comfort Zone.txt", lines);
				
				// Then refresh data grid views.
				MainForm.LoadDgv();
				// MainForm.ToRevit();
				Close();
			}
		}
		
		// Button -- Cancel
		void Button2Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
