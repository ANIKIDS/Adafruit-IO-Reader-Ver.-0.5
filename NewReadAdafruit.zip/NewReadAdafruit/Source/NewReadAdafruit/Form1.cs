﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 2018/11/5
 * Time: 10:32
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.ApplicationServices;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using System.Net;
using System.Text.RegularExpressions;

namespace NewReadAdafruit
{
	/// <summary>
	/// Description of Form1.
	/// </summary>
	/// 
	

	
	public partial class Form1 : System.Windows.Forms.Form
	{
		//Create data tables.
		public DataTable TempDataTable = new DataTable();
		public DataTable HumidDataTable = new DataTable();
		
		//=============================Strings and variables========================//
		
		public static string feed_id;
		public static string element_id;
//		double MaxTemp = 0;
//		double MinTemp = 0;
//		double MaxHumid = 0;
//		double MinHumid = 0;
		public static string RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
		public static string PicRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Pictures\";
		
		//=============================Form1 Initialization=========================//
		
		public Form1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	
		//=============================Custom Functions=============================//
				
		public void DateFilter()
		{
			// Object reference
			Form2 Form2 = new Form2(this);
			
			// Set date ranges
			string DateRange = "";
			
			// Apply different date ranges
			if (Form2.StartDate.Checked == true && Form2.EndDate.Checked == true)
			{
				string DateRangeSE = "created_at >= '" + Form2.SY + "-" + Form2.SM + "-" + Form2.SD + "T00:00:00' " +
					"and created_at <= '" + Form2.EY + "-" + Form2.EM + "-" + Form2.ED + "T23:59:59'";
				DateRange = DateRangeSE;
			}
			
			if (Form2.StartDate.Checked == true && Form2.EndDate.Checked == false)
			{
				string DateRangeS = "created_at >= '" + Form2.SY + "-" + Form2.SM + "-" + Form2.SD + "T00:00:00'";
				DateRange = DateRangeS;
			}
			
			if (Form2.StartDate.Checked == false && Form2.EndDate.Checked == true)
			{
				string DateRangeE = "created_at <= '" + Form2.EY + "-" + Form2.EM + "-" + Form2.ED + "T23:59:59'";
				DateRange = DateRangeE;
			}
			
			// Refresh data views
			DataView PartialTempView = new DataView();
			PartialTempView = TempDataTable.DefaultView;
			PartialTempView.RowFilter = DateRange;
			
			DataView PartialHumidView = new DataView();
			PartialHumidView = HumidDataTable.DefaultView;
			PartialHumidView.RowFilter = DateRange;
			
			ColorScheme();
			
			// Apply date range to the line plat as well.
			TempLinePlot.Refresh();
			TempLinePlot.DataSource = PartialTempView;
			TempLinePlot.Series["Temperature (℉)"].XValueMember = "created_at";
			TempLinePlot.Series["Temperature (℉)"].YValueMembers = "value";
			TempLinePlot.DataBind();
			
			HumidLinePlot.Refresh();
			HumidLinePlot.DataSource = PartialHumidView;
			HumidLinePlot.Series["Relative Humidity (%)"].XValueMember = "created_at";
			HumidLinePlot.Series["Relative Humidity (%)"].YValueMembers = "value";
			HumidLinePlot.DataBind();
		}
		
		public void ColorScheme()
		{
			// Color scheme
			foreach (DataGridViewRow TempRow in DataGridView1.Rows)
			{
				// Temperature too low
				if (Convert.ToDecimal(TempRow.Cells[1].Value) < Convert.ToDecimal(Form3.LT))
				{
					TempRow.Cells[1].Style.BackColor = System.Drawing.Color.Cyan;
					TempRow.Cells[5].Style.BackColor = System.Drawing.Color.Cyan;
				}
				
				// Temperature too high
				if (Convert.ToDecimal(TempRow.Cells[1].Value) > Convert.ToDecimal(Form3.HT))
				{
					TempRow.Cells[1].Style.BackColor = System.Drawing.Color.Orange;
					TempRow.Cells[5].Style.BackColor = System.Drawing.Color.Orange;
				}
				
//				if (MaxTemp < Convert.ToDouble(TempRow.Cells[1].Value)) {MaxTemp = Convert.ToDouble(TempRow.Cells[1].Value);}
//				MinTemp = MaxTemp;
//				if (MinTemp < Convert.ToDouble(TempRow.Cells[1].Value)) {MinTemp = Convert.ToDouble(TempRow.Cells[1].Value);}
			}
			
			foreach (DataGridViewRow HumidRow in DataGridView2.Rows)
			{
				// Humidity too low
				if (Convert.ToDecimal(HumidRow.Cells[1].Value) < Convert.ToDecimal(Form3.LH))
				{
					HumidRow.Cells[1].Style.BackColor = System.Drawing.Color.Cyan;
					HumidRow.Cells[5].Style.BackColor = System.Drawing.Color.Cyan;
				}
				
				// Humidity too high
				if (Convert.ToDecimal(HumidRow.Cells[1].Value) > Convert.ToDecimal(Form3.HH))
				{
					HumidRow.Cells[1].Style.BackColor = System.Drawing.Color.Orange;
					HumidRow.Cells[5].Style.BackColor = System.Drawing.Color.Orange;
				}
				
//				if (MaxHumid < Convert.ToDouble(HumidRow.Cells[1].Value)) {MaxHumid = Convert.ToDouble(HumidRow.Cells[1].Value);}
//				MinHumid = MaxHumid;
//				if (MinHumid < Convert.ToDouble(HumidRow.Cells[1].Value)) {MinHumid = Convert.ToDouble(HumidRow.Cells[1].Value);}
			}
		}
		
		public void LoadDgv()
		{		
			// Reset filters
			ResetFilter.Enabled = true;
			NoTempLinePlot.Visible = false;
			NoHumidLinePlot.Visible = false;
			EnableFaultyOnly.Enabled = true;
			EnableFaultyOnly.Checked = false;
			EnableDateFilter.Enabled = true;
			EnableDateFilter.Checked = false;
			SetDate.Enabled = true;
			
			// A file path is composed of three parts -- file path, file name and the file extension.

			if (SelectSensor.Text == "Watt Hall Building Science Corner") {TBElementId.Text = "1304799";}
			if (SelectSensor.Text == "Watt Hall Upper Rosendin") {TBElementId.Text = "1304568";}
			if (SelectSensor.Text == "Watt Hall Lower Rosendin") {TBElementId.Text = "1305148";}
			if (SelectSensor.Text == "Watt Hall 212") {TBElementId.Text = "1304930";}
			if (SelectSensor.Text == "Watt Hall B1") {TBElementId.Text = "1305363";}
			
			#region Temperature data goes to DataGridView1.
			
			// Dispose datatable
			
			TempDataTable.Dispose();
			TempDataTable = new DataTable();
			DataGridView1.Refresh();
			DataGridView1.DataSource = TempDataTable;
			DataGridView1.AllowUserToAddRows = false;
			
			string SensorInfoPath = RealTimeRepository + SelectSensor.Text + " - Temp.csv";
			string[] raw_text = System.IO.File.ReadAllLines(SensorInfoPath);
			string[] data_col = null;
			
			int x = 0;
			
			// Generate columns and rows
			foreach (string text_line in raw_text)
			{
				data_col = text_line.Split(',');
				
				// Import the header.
				if (x == 0)
				{
					for(int i = 0; i < data_col.Count(); i++)
					{
						TempDataTable.Columns.Add(data_col[i]);
					}
					x++;
				}
				
				// Import data.
				else
				{
					TempDataTable.Rows.Add(data_col);
				}
			}
			
			for (int TempColNum = 0; TempColNum < 6; TempColNum ++)
			{
				DataGridView1.Columns[TempColNum].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
				DataGridView1.Columns[TempColNum].SortMode = DataGridViewColumnSortMode.NotSortable;
			}
			
			#endregion
			
			#region Humidity data goes to DataGridView2.
			
			// Dispose datatable
			
			HumidDataTable.Dispose();
			HumidDataTable = new DataTable();
			DataGridView2.Refresh();
			DataGridView2.DataSource = HumidDataTable;
			DataGridView2.AllowUserToAddRows = false;
			
			SensorInfoPath = RealTimeRepository + SelectSensor.Text + " - Humid.csv";
			raw_text = System.IO.File.ReadAllLines(SensorInfoPath);
			data_col = null;
			
			x = 0;
			
			// Generate columns and rows
			foreach (string text_line in raw_text)
			{
				data_col = text_line.Split(',');
				
				// Import the header.
				if (x == 0)
				{
					for(int i = 0; i < data_col.Count(); i++)
					{
						HumidDataTable.Columns.Add(data_col[i]);
					}
					x++;
				}
				
				// Import data.
				else
				{
					HumidDataTable.Rows.Add(data_col);
				}
			}
			
			for (int HumidColNum = 0; HumidColNum < 6; HumidColNum ++)
			{
				DataGridView2.Columns[HumidColNum].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
				DataGridView2.Columns[HumidColNum].SortMode = DataGridViewColumnSortMode.NotSortable;
			}
			
			#endregion
			
			#region Load room and sensor photographs
			
			RoomPhoto.Image = Image.FromFile(PicRepository + SelectSensor.Text + " - Room.jpg");
			SensorPhoto.Image = Image.FromFile(PicRepository + SelectSensor.Text + " - Sensor.jpg");
			
			#endregion
			
			#region Set color scheme based on comfort zone
			
			ColorScheme();
			
			#endregion
			
			#region Generate line chart
			TempLinePlot.DataSource = TempDataTable;
			TempLinePlot.Series["Temperature (℉)"].XValueMember = "created_at";
			TempLinePlot.Series["Temperature (℉)"].YValueMembers = "value";
			TempLinePlot.ChartAreas[0].AxisY2.Minimum = 40;
			TempLinePlot.ChartAreas[0].AxisY.Minimum = 40;
			TempLinePlot.DataBind();
			
			// Reverse X axis
			ChartArea Tlp = TempLinePlot.ChartAreas[0];
			Tlp.AxisY2.Enabled = AxisEnabled.True;
			Tlp.AxisY.Enabled = AxisEnabled.False;
			Tlp.AxisX.IsReversed = true;
			
			HumidLinePlot.DataSource = HumidDataTable;
			HumidLinePlot.Series["Relative Humidity (%)"].XValueMember = "created_at";
			HumidLinePlot.Series["Relative Humidity (%)"].YValueMembers = "value";
			HumidLinePlot.DataBind();
			
			// Reverse X axis
			ChartArea Hlp = HumidLinePlot.ChartAreas[0];
			Hlp.AxisY2.Enabled = AxisEnabled.True;
			Hlp.AxisY.Enabled = AxisEnabled.False;
			Hlp.AxisX.IsReversed = true;
			
			#endregion
		}
			
		//=============================Tool Strip Bar Commands=======================//
		
		#region File -- Sync data with Adafruit IO
		
		void ToolStripMenuItem3Click(object sender, System.EventArgs e)
		{
			using (var client = new WebClient())
			{
				string CurrentTxtFile = "";
				string CurrentCsvFile = "";
				
				for (int FileCounter = 0; FileCounter <= 9; FileCounter++)
				{
					// Create list of data files for the loop below.
					if (FileCounter == 0) {CurrentTxtFile = "node-13.temp"; CurrentCsvFile = "Watt Hall Building Science Corner - Temp";}
					if (FileCounter == 1) {CurrentTxtFile = "node-13.humid"; CurrentCsvFile = "Watt Hall Building Science Corner - Humid";}
					if (FileCounter == 2) {CurrentTxtFile = "node-7.temp"; CurrentCsvFile = "Watt Hall Upper Rosendin - Temp";}
					if (FileCounter == 3) {CurrentTxtFile = "node-7.humid"; CurrentCsvFile = "Watt Hall Upper Rosendin - Humid";}
					if (FileCounter == 4) {CurrentTxtFile = "node-8.temp"; CurrentCsvFile = "Watt Hall Lower Rosendin - Temp";}
					if (FileCounter == 5) {CurrentTxtFile = "node-8.humid"; CurrentCsvFile = "Watt Hall Lower Rosendin - Humid";}
					if (FileCounter == 6) {CurrentTxtFile = "node-11.temp"; CurrentCsvFile = "Watt Hall 212 - Temp";}
					if (FileCounter == 7) {CurrentTxtFile = "node-11.humid"; CurrentCsvFile = "Watt Hall 212 - Humid";}
					if (FileCounter == 8) {CurrentTxtFile = "node-3.temp"; CurrentCsvFile = "Watt Hall B1 - Temp";}
					if (FileCounter == 9) {CurrentTxtFile = "node-3.humid"; CurrentCsvFile = "Watt Hall B1 - Humid";}
					
					// Set the file path and download from Adafruit IO.
					
					// Get the URL, download, rename the file and save it to the designated file path
					// SENSITIVE DATA, DO NOT SHARE
					string RealTimeRepository = @"E:\USC\2018 Fall\ARCH692a\Tool Development\Object\Real-time\";
					client.DownloadFile("https://io.adafruit.com/api/v2/buildingscience/feeds/" + CurrentTxtFile +
					                    "/data?X-AIO-Key=1281bb70b3f277a12c018fe75d6f464017fa46a2",
					                    RealTimeRepository + CurrentTxtFile + ".txt");
					
					// Start a new line for every feed value.
					
					// Remove brackets and braces.
					string newline = File.ReadAllText(RealTimeRepository + CurrentTxtFile + ".txt");
					newline = newline.Replace("[","");
					newline = newline.Replace("]",",");
					newline = newline.Replace("{","");
					newline = newline.Replace("},","},\r\n");
					newline = newline.Replace("}","");

					// Remove attribute names.
					newline = newline.Replace("\"id\":","");
					newline = newline.Replace("\"value\":","");
					newline = newline.Replace("\"feed_id\":","");
					newline = newline.Replace("\"feed_key\":","");
					newline = newline.Replace("\"created_at\":","");
					newline = newline.Replace("\"location\":null,\"lat\":null,\"lon\":null,\"ele\":null,\"created_epoch\":","");
					newline = newline.Replace("\"expiration\":","");
					newline = newline.Replace("\"","");
					
					// Use regular expression to remove "created_epoch" and "expiration".
					// Need improvement.
					newline = Regex.Replace(newline,"Z,15[^Z]+Z","");
					
					// Pruning done.
					File.WriteAllText(RealTimeRepository + CurrentTxtFile + ".txt", newline);
					
					// The StreamWriter will create the file if it doesn't exist.
					TextWriter tw = new StreamWriter(RealTimeRepository + CurrentCsvFile + ".csv");
					tw.WriteLine("id,value,feed_id,feed_key,created_at,status");
					
					// Close the file before appending text. Or it will cause error.
					tw.Close();
					File.AppendAllText(RealTimeRepository + CurrentCsvFile + ".csv", newline);
				}
			}
			
			// Synchronization done.
			MessageBox.Show("All sensor data have been synchronized with Adafruit IO server.\n\n" +
			                "Any existing files have been overwritten.","Synchronization Completed!",
			                MessageBoxButtons.OK,MessageBoxIcon.Information);
		}
		
		#endregion
		
		#region File -- Clear All Data
		void ToolStripMenuItem1Click(object sender, EventArgs e)
		{
			// Disable filters
			//applyFiltersToolStripMenuItem.Enabled = false;
			ResetFilter.Enabled = false;
			NoTempLinePlot.Visible = true;
			EnableFaultyOnly.Enabled = false;
			EnableDateFilter.Enabled = false;
			SetDate.Enabled = false;
			
			#region Dispose datatable
			TempDataTable.Dispose();
			TempDataTable = new DataTable();
			DataGridView1.Refresh();
			DataGridView1.DataSource = TempDataTable;
			
			HumidDataTable.Dispose();
			HumidDataTable = new DataTable();
			DataGridView2.Refresh();
			DataGridView2.DataSource = TempDataTable;
			#endregion
			
			RoomPhoto.Image = null;
			SensorPhoto.Image = null;
		}
		
		#endregion
		
		// File -- Exit
		void ExitToolStripMenuItem1Click(object sender, EventArgs e)
		{
			Close();
		}
		
		// Edit -- Comfort zone
		void ApplyFiltersToolStripMenuItemClick(object sender, EventArgs e)
		{
			// Go to filter window.
			Form3 Form3 = new Form3(this);
			Form3.ShowDialog();
		}
		
		// Edit -- File Path
		// Still working on it...
		
		// Help -- About
		void AboutToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Adafruit IO Reader Version 0.5\nDeveloped By: Gelin Su (University of Southern California)\n" +
			                "Last Update: 02/04/2019\nContact: gelinsu@usc.edu","About",
			                MessageBoxButtons.OK,MessageBoxIcon.Information);
		}
		
		//=============================Interface Commands=============================//
		
		// ALL FEATURES START FROM HERE - Select a sensor and open corresponding CSV file.
		void SelectSensorSelectedIndexChanged(object sender, EventArgs e)
		{
			LoadDgv();
		}
		
		// Reset filter.
		void ResetFilterClick(object sender, EventArgs e)
		{
			EnableDateFilter.Checked = false;
			EnableFaultyOnly.Checked = false;
			
			TempDataTable.DefaultView.RowFilter = string.Empty;
			HumidDataTable.DefaultView.RowFilter = string.Empty;
			
			// Reset filter for the line plot as well.
			NoTempLinePlot.Visible = false;
			TempLinePlot.Refresh();
			TempLinePlot.DataSource = TempDataTable;
			TempLinePlot.Series["Temperature (℉)"].XValueMember = "created_at";
			TempLinePlot.Series["Temperature (℉)"].YValueMembers = "value";
			TempLinePlot.DataBind();
			
			NoHumidLinePlot.Visible = false;
			HumidLinePlot.Refresh();
			HumidLinePlot.DataSource = HumidDataTable;
			HumidLinePlot.Series["Relative Humidity (%)"].XValueMember = "created_at";
			HumidLinePlot.Series["Relative Humidity (%)"].YValueMembers = "value";
			HumidLinePlot.DataBind();
		}
		
		// All values and faulty values
		void FaultyOnlyCheckedChanged(object sender, EventArgs e)
		{
			if (EnableFaultyOnly.Checked == true)
			{
				// Filter temperature values.
				DataView TempDataView = new DataView();
				TempDataView = TempDataTable.DefaultView;
				TempDataView.RowFilter = "value > '" + Form3.HT + "' or value < '" + Form3.LT + "'";
				NoTempLinePlot.Visible = true;
				
				// Filter RH values.
				DataView HumidDataView = new DataView();
				HumidDataView = HumidDataTable.DefaultView;
				HumidDataView.RowFilter = "value > '" + Form3.HH + "' or value < '" + Form3.LH + "'";
				NoHumidLinePlot.Visible = true;
				
				ColorScheme();
			}
			
			else
			{
				TempDataTable.DefaultView.RowFilter = string.Empty;
				HumidDataTable.DefaultView.RowFilter = string.Empty;
				NoTempLinePlot.Visible = false;
				NoHumidLinePlot.Visible = false;
				
				ColorScheme();
			}
		}
		
		// Date Filter
		void EnableDateFilterCheckedChanged(object sender, EventArgs e)
		{
			
		}
		
		// Set start and end date
		void SetDateClick(object sender, EventArgs e)
		{
			Form2 Form2 = new Form2(this);
			Form2.ShowDialog();
		}
	}
}
