﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 2/4/2019
 * Time: 15:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace NewReadAdafruit
{
	partial class Form2
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.StartDate = new System.Windows.Forms.CheckBox();
			this.EndDate = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.StartYear = new System.Windows.Forms.ComboBox();
			this.StartMonth = new System.Windows.Forms.ComboBox();
			this.StartDay = new System.Windows.Forms.ComboBox();
			this.EndYear = new System.Windows.Forms.ComboBox();
			this.EndMonth = new System.Windows.Forms.ComboBox();
			this.EndDay = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(25, 14);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(283, 34);
			this.label1.TabIndex = 0;
			this.label1.Text = "Please check at least one box and set the date range (YYYYMMDD):";
			this.label1.UseCompatibleTextRendering = true;
			// 
			// StartDate
			// 
			this.StartDate.Location = new System.Drawing.Point(25, 69);
			this.StartDate.Name = "StartDate";
			this.StartDate.Size = new System.Drawing.Size(75, 24);
			this.StartDate.TabIndex = 1;
			this.StartDate.Text = "Start Date";
			this.StartDate.UseCompatibleTextRendering = true;
			this.StartDate.UseVisualStyleBackColor = true;
			this.StartDate.CheckedChanged += new System.EventHandler(this.StartDateCheckedChanged);
			// 
			// EndDate
			// 
			this.EndDate.Location = new System.Drawing.Point(25, 99);
			this.EndDate.Name = "EndDate";
			this.EndDate.Size = new System.Drawing.Size(75, 24);
			this.EndDate.TabIndex = 2;
			this.EndDate.Text = "End Date";
			this.EndDate.UseCompatibleTextRendering = true;
			this.EndDate.UseVisualStyleBackColor = true;
			this.EndDate.CheckedChanged += new System.EventHandler(this.EndDateCheckedChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(119, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(55, 21);
			this.label2.TabIndex = 9;
			this.label2.Text = "Year";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label2.UseCompatibleTextRendering = true;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(196, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(53, 21);
			this.label3.TabIndex = 10;
			this.label3.Text = "Month";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label3.UseCompatibleTextRendering = true;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(255, 48);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(53, 21);
			this.label4.TabIndex = 11;
			this.label4.Text = "Day";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label4.UseCompatibleTextRendering = true;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(146, 140);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 12;
			this.button1.Text = "OK";
			this.button1.UseCompatibleTextRendering = true;
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(233, 140);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 13;
			this.button2.Text = "Cancel";
			this.button2.UseCompatibleTextRendering = true;
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// SY
			// 
			this.StartYear.FormattingEnabled = true;
			this.StartYear.Items.AddRange(new object[] {
									"2018",
									"2019"});
			this.StartYear.Location = new System.Drawing.Point(119, 71);
			this.StartYear.Name = "SY";
			this.StartYear.Size = new System.Drawing.Size(71, 21);
			this.StartYear.TabIndex = 14;
			// 
			// SM
			// 
			this.StartMonth.FormattingEnabled = true;
			this.StartMonth.Items.AddRange(new object[] {
									"01",
									"02",
									"03",
									"04",
									"05",
									"06",
									"07",
									"08",
									"09",
									"10",
									"11",
									"12"});
			this.StartMonth.Location = new System.Drawing.Point(196, 71);
			this.StartMonth.Name = "SM";
			this.StartMonth.Size = new System.Drawing.Size(53, 21);
			this.StartMonth.TabIndex = 15;
			// 
			// SD
			// 
			this.StartDay.FormattingEnabled = true;
			this.StartDay.Items.AddRange(new object[] {
									"01",
									"02",
									"03",
									"04",
									"05",
									"06",
									"07",
									"08",
									"09",
									"10",
									"11",
									"12",
									"13",
									"14",
									"15",
									"16",
									"17",
									"18",
									"19",
									"20",
									"21",
									"22",
									"23",
									"24",
									"25",
									"26",
									"27",
									"28",
									"29",
									"30",
									"31"});
			this.StartDay.Location = new System.Drawing.Point(255, 71);
			this.StartDay.Name = "SD";
			this.StartDay.Size = new System.Drawing.Size(53, 21);
			this.StartDay.TabIndex = 16;
			// 
			// EY
			// 
			this.EndYear.FormattingEnabled = true;
			this.EndYear.Items.AddRange(new object[] {
									"2018",
									"2019"});
			this.EndYear.Location = new System.Drawing.Point(119, 101);
			this.EndYear.Name = "EY";
			this.EndYear.Size = new System.Drawing.Size(71, 21);
			this.EndYear.TabIndex = 17;
			// 
			// EM
			// 
			this.EndMonth.FormattingEnabled = true;
			this.EndMonth.Items.AddRange(new object[] {
									"01",
									"02",
									"03",
									"04",
									"05",
									"06",
									"07",
									"08",
									"09",
									"10",
									"11",
									"12"});
			this.EndMonth.Location = new System.Drawing.Point(196, 101);
			this.EndMonth.Name = "EM";
			this.EndMonth.Size = new System.Drawing.Size(53, 21);
			this.EndMonth.TabIndex = 18;
			// 
			// ED
			// 
			this.EndDay.FormattingEnabled = true;
			this.EndDay.Items.AddRange(new object[] {
									"01",
									"02",
									"03",
									"04",
									"05",
									"06",
									"07",
									"08",
									"09",
									"10",
									"11",
									"12",
									"13",
									"14",
									"15",
									"16",
									"17",
									"18",
									"19",
									"20",
									"21",
									"22",
									"23",
									"24",
									"25",
									"26",
									"27",
									"28",
									"29",
									"30",
									"31"});
			this.EndDay.Location = new System.Drawing.Point(255, 101);
			this.EndDay.Name = "ED";
			this.EndDay.Size = new System.Drawing.Size(53, 21);
			this.EndDay.TabIndex = 19;
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(331, 179);
			this.Controls.Add(this.EndDay);
			this.Controls.Add(this.EndMonth);
			this.Controls.Add(this.EndYear);
			this.Controls.Add(this.StartDay);
			this.Controls.Add(this.StartMonth);
			this.Controls.Add(this.StartYear);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.EndDate);
			this.Controls.Add(this.StartDate);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form2";
			this.Text = "Date Filter";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.ComboBox EndDay;
		private System.Windows.Forms.ComboBox EndMonth;
		private System.Windows.Forms.ComboBox EndYear;
		private System.Windows.Forms.ComboBox StartDay;
		private System.Windows.Forms.ComboBox StartMonth;
		private System.Windows.Forms.ComboBox StartYear;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		public System.Windows.Forms.CheckBox EndDate;
		public System.Windows.Forms.CheckBox StartDate;
		private System.Windows.Forms.Label label1;
	}
}
