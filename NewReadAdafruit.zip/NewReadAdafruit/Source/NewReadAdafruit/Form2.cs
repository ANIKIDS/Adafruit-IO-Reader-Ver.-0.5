﻿/*
 * Created by SharpDevelop.
 * User: gelin
 * Date: 2/4/2019
 * Time: 15:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace NewReadAdafruit
{
	/// <summary>
	/// Description of Form2.
	/// </summary>
	public partial class Form2 : Form
	{
		// Declaration of the main form.
		Form1 MainForm;
		
		//=============================Strings======================================//
		
		public static string SY;
		public static string SM;
		public static string SD;
		public static string EY;
		public static string EM;
		public static string ED;
		
		public Form2(Form1 MainForm)
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			this.MainForm = MainForm;
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
			StartDate.Checked = true;
			EndDate.Checked = true;
			
			StartYear.Text = "2018";
			StartMonth.Text = "12";
			StartDay.Text = "12";
			EndYear.Text = "2018";
			EndMonth.Text = "12";
			EndDay.Text = "13";
			
		}
		
		// Decide if both dates are used.
		void StartDateCheckedChanged(object sender, EventArgs e)
		{
			if (StartDate.Checked == true)
			{
				StartYear.Enabled = true;
				StartMonth.Enabled = true;
				StartDay.Enabled = true;
			}
			
			if (StartDate.Checked == false)
			{
				StartYear.Enabled = false;
				StartMonth.Enabled = false;
				StartDay.Enabled = false;				
			}
		}
		
		void EndDateCheckedChanged(object sender, EventArgs e)
		{
			if (EndDate.Checked == true)
			{
				EndYear.Enabled = true;
				EndMonth.Enabled = true;
				EndDay.Enabled = true;
			}
			
			if (EndDate.Checked == false)
			{
				EndYear.Enabled = false;
				EndMonth.Enabled = false;
				EndDay.Enabled = false;				
			}
		}
		
		// OK button
		void Button1Click(object sender, EventArgs e)
		{
			if (StartDate.Checked == false && EndDate.Checked == false)
			{
				MessageBox.Show("Please check at least one box to set the date range.","Date Range",
				                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
				return;
			}
			
			// Data validation only when both start and end date boxes are checked
			if (StartDate.Checked == true && EndDate.Checked == true)
			{
				// Year
				int InvalidYear = string.Compare(StartYear.Text, EndYear.Text);
				if (InvalidYear == 1)
				{
					MessageBox.Show("The start year cannot be later than the end year.","Invalid Year Range",
					                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
					StartYear.Focus();
					return;
				}
				
				// Month
				int InvalidMonth = string.Compare(StartMonth.Text, EndMonth.Text);
				if (InvalidMonth == 1)
				{
					MessageBox.Show("The start month cannot be later than the end month.","Invalid Month Range",
					                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
					StartMonth.Focus();
					return;
				}
				
				// Day
				int InvalidDay = string.Compare(StartDay.Text, EndDay.Text);
				if (InvalidDay == 1)
				{
					MessageBox.Show("The start day cannot be later than the end day.","Invalid Day Range",
					                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
					StartDay.Focus();
					return;
				}
			}
			
			// Apply date filter
			
			SY = StartYear.Text;
			SM = StartMonth.Text;
			SD = StartDay.Text;
			EY = EndYear.Text;
			EM = EndMonth.Text;
			ED = EndDay.Text;
			
			MainForm.DateFilter();
			Close();

		}
		
		// Cancel button
		void Button2Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
